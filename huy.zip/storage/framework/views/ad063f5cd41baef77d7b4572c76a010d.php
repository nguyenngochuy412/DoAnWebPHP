

<?php $__env->startSection('title', 'PetStore - Thiên đường thú cưng'); ?>

<?php $__env->startSection('content'); ?>

<!-- Featured Pets -->
<?php if(isset($featuredPets) && $featuredPets->count() > 0): ?>
<section class="py-5">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content:center; margin-bottom: 20px;">
            <h2>Thú cưng nổi bật</h2>
        </div>
        <div class="row">
            <?php $__currentLoopData = $featuredPets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card pet-card shadow-sm h-100">
                    <?php if($pet->image): ?>
                        <img src="<?php echo e($pet->image_url); ?>" 
                             class="card-img-top" alt="<?php echo e($pet->name); ?>" style="height: 200px; object-fit: cover;">
                    <?php else: ?>
                        <img src="/images/default-pet.jpg" 
                             class="card-img-top" alt="<?php echo e($pet->name); ?>" style="height: 200px; object-fit: cover;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($pet->name); ?></h5>
                        <p class="card-text">
                            <small class="text-muted"><?php echo e($pet->breed); ?> • <?php echo e($pet->age); ?> tháng</small>
                        </p>
                        <div class="price mb-2">
                            <?php if($pet->sale_price): ?>
                                <span class="text-decoration-line-through text-muted">
                                    <?php echo e(number_format($pet->price, 0, ',', '.')); ?>đ
                                </span>
                                <span class="text-danger fw-bold">
                                    <?php echo e(number_format($pet->sale_price, 0, ',', '.')); ?>đ
                                </span>
                            <?php else: ?>
                                <span class="fw-bold"><?php echo e(number_format($pet->price, 0, ',', '.')); ?>đ</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <a href="<?php echo e(route('pets.show', $pet->id)); ?>" class="btn btn-outline-primary btn-sm">
                                Xem chi tiết
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Cuối section Featured Pets -->
    <?php if(isset($featuredPets) && $featuredPets->count() > 0): ?>
    <!-- ... existing code ... -->

    <div class="text-center mt-4">
        <a href="<?php echo e(route('pets.index')); ?>" class="btn btn-primary btn-lg">
            <i class="fas fa-paw me-2"></i> Xem tất cả <?php echo e(count($featuredPets) ?? 0); ?> thú cưng
        </a>
    </div>
    <?php endif; ?>
</section>

<?php else: ?>
<section class="py-5">
    <div class="container text-center">
        <h2 class="mb-4">Chưa có thú cưng nổi bật</h2>
        <p class="text-muted mb-4">Hãy thêm thú cưng đầu tiên của bạn!</p>
         <a href="<?php echo e(route('admin.pets.create')); ?>" class="btn btn-success btn-lg">
            <i class="fas fa-plus me-2"></i> Thêm thú cưng ngay
        </a>
    </div>
</section>
<?php endif; ?>

<!-- Categories -->
<?php if(isset($categories) && $categories->count() > 0): ?>
<section class="py-5 bg-light">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content:center; margin-bottom: 20px;">
            <h2>Danh mục thú cưng</h2>
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-info btn-sm ms-2">
                <i class="fas fa-folder-plus"></i> Thêm danh mục
            </a>
        </div>
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-3">
                <div class="category-card bg-white shadow-sm p-4 text-center">
                    <i class="fas fa-paw fa-3x mb-3 text-primary"></i>
                    <h5><?php echo e($category->name); ?></h5>
                    <p class="text-muted"><?php echo e($category->pets_count ?? 0); ?> thú cưng</p>
                    <a href="<?php echo e(route('pets.index', ['category' => $category->slug])); ?>" 
                       class="btn btn-outline-primary btn-sm">
                        Xem tất cả
                    </a>
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" 
                            class="btn btn-warning btn-sm">Sửa</a>
                        <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" 
                                    onclick="return confirm('Xóa thú cưng?')">
                                Xóa
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php else: ?>
<section class="py-5">
    <div class="container text-center">
        <h2 class="mb-4">Chưa có danh mục thú cưng</h2>
        <p class="text-muted mb-4">Hãy thêm danh mục thú cưng đầu tiên của bạn!</p>
         <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-success btn-lg">
            <i class="fas fa-plus me-2"></i> Thêm danh mục thú cưng ngay
        </a>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp1\htdocs\DoAnWeb_T3Ca3\pet-store\resources\views/layouts/home.blade.php ENDPATH**/ ?>