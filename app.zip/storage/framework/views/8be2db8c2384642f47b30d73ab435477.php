

<?php $__env->startSection('title', $pet->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                 <?php if($pet->image): ?>
                    <img src="<?php echo e($pet->image_url); ?>" 
                            class="card-img-top" alt="<?php echo e($pet->name); ?>" style="height: 480px; object-fit: cover;">
                <?php else: ?>
                    <img src="/images/default-pet.jpg" 
                            class="card-img-top" alt="<?php echo e($pet->name); ?>" style="height: 480px; object-fit: cover;">
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title"><?php echo e($pet->name); ?></h2>
                    
                    <div class="mb-3">
                        <span class="badge bg-primary"><?php echo e($pet->category->name ?? 'N/A'); ?></span>
                        <?php if($pet->is_featured): ?>
                            <span class="badge bg-warning">Nổi bật</span>
                        <?php endif; ?>
                        <span class="badge bg-<?php echo e($pet->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($pet->is_active ? 'Đang bán' : 'Ngừng bán'); ?>

                        </span>
                    </div>

                    <?php if($pet->sale_price): ?>
                        <h3 class="text-danger">
                            <?php echo e($pet->formatted_price); ?>

                        </h3>
                        <h3 class="text-danger">
                            <?php echo e($pet->formatted_price); ?>

                        </h3>
                    <?php else: ?>
                        <h3 class="text-danger"><?php echo e($pet->formatted_price); ?></h3>
                    <?php endif; ?>
                    <hr>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Tuổi:</strong> <?php echo e($pet->age); ?> tháng</p>
                            <p><strong>Giới tính:</strong> <?php echo e($pet->gender_text); ?></p>
                            <p><strong>Màu sắc:</strong> <?php echo e($pet->color); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Cân nặng:</strong> <?php echo e(intval($pet->weight)); ?> kg</p>
                            <p><strong>Tình trạng vaccine:</strong> <?php echo e($pet->vaccination_text); ?></p> 
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h5>Mô tả:</h5>
                    <p><?php echo e($pet->description); ?></p>
                    
                    <div class="mt-4">
                        <a href="<?php echo e(route('admin.pets.edit', $pet)); ?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Chỉnh sửa
                        </a>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Quay lại
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp1\htdocs\DoAnWeb_T3Ca3\pet-store\resources\views/admin/pets/show.blade.php ENDPATH**/ ?>